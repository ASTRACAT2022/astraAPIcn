# 项目
这是在[cmliu edgetunnel](https://github.com/cmliu/edgetunnel)基础上进行修改，优化响应快稳定连接。

## 邦定KV
KV变量名：KV

添加高级设置可在线设置：PROXYIP、SOCKS5、SUB 、SUBAPI、SUBCONFIG

# 变量
| 常用变量 | 示例 |
|--------|---------|
| UUID  | fca6e4ec-c882-4876-992c-cf354fd3f2ae |
| PROXYIP | bpb.radically.pro/1.2.3.4 |
| SOCKS5 | user:password@1.2.3.4 :2222 |
| ADD | icook.tw:8443#优选域名/1.2.3.4 :8443#优选IP |
| ADDAPI | https://raw.githubusercontent.com/yd072/youxuanyuming/refs/heads/main/ip.txt |
| ADDNOTLS | icook.tw:8443#优选域名/1.2.3.4 :8443#优选IP |
| ADDNOTLSAPI | https://raw.githubusercontent.com/yd072/youxuanyuming/refs/heads/main/ip.txt |
| SUB | 自定义 |
| SUBAPI | 自定义 |
| ····· | ····· |

# 感谢
[cmliu](https://github.com/cmliu/edgetunnel)


